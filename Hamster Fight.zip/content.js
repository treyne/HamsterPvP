console.log('Hamster Madness 2.0: Скрипт загружен');

function processIframes() {
  document.querySelectorAll('iframe').forEach((ifr, index) => {
    const src = ifr.getAttribute("src"); // Берем исходный атрибут src
    if (!src) {
      console.log(`Iframe #${index}: src отсутствует`);
      return;
    }
    console.log(`Iframe #${index}: src = ${src}`); // Выводим весь src
  });
}

// Изначальная проверка
processIframes();

// Используем MutationObserver для отслеживания появления новых iframe
const observer = new MutationObserver(() => {
  processIframes();
});

observer.observe(document.body, { childList: true, subtree: true });