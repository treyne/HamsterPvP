// background.js
console.log("Background script loaded.");